﻿
export class Constants  {
   private apiurl = 'http://localhost:8095/erp/'; 
  
}
