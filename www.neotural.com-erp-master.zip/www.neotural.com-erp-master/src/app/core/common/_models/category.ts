﻿import { Common } from "./common";

export class Category extends Common {

   id: string; 
   name: string;
   description: string;
   categorycode: string;
   status: string;

}
