﻿import { Common } from "./common";

export class Units extends Common {
   id: string;
   unitname: string; 
   unitsymbol: string;
   quantityname: string;
   quantitysymbol: string;
   dimensionsymbol: string;
}
