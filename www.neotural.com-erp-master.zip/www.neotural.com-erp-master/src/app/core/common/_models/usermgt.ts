﻿import { Common } from "./common";

export class Usermgt extends Common {

   id: string; 
   name: string;
   empCode: string;
   rank: string;
   contactNumber: string;
   purchaseOrdeData:any;
}
