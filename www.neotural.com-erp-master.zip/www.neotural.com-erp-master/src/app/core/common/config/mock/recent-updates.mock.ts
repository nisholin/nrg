import { RecentUpdate } from "src/app/core/components/navigation/navigation.model";

export const RecentUpdatesMock: RecentUpdate[] = [
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  },
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  },
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  },
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  },
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  },
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  },
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  },
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  },
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  },
  {
    date: "30/01/19",
    update: "Purchase from ‘Carbon Composite’ Complete!"
  },
  {
    date: "05/02/19",
    update: "Stock Updated"
  }
];
