import { Stock } from "src/app/core/components/navigation/navigation.model";

export const StocksMock: Stock[] = [
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  },
  {
    item: "Twill 2x2 200 gsm",
    quantity: "24R | 692 M"
  },
  {
    item: "Twill Red Reflective 2x2 200 gsm",
    quantity: "10R | 280 M"
  }
];
