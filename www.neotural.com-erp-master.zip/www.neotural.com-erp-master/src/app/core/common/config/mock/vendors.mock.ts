import { Vendor } from "../../../../templates/modules/vendor-and-customer/components/vendor-and-customer-list/vendor-and-customer-list.component.model";

export const VendorsMock: Vendor[] = [
  {
    vendorCode: 301002,
    vendorName: "Sam",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301001,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301003,
    vendorName: "John",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301004,
    vendorName: "Mary",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301005,
    vendorName: "Peter",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301006,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301001,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301002,
    vendorName: "Sam",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301003,
    vendorName: "John",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301004,
    vendorName: "Mary",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301005,
    vendorName: "Peter",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301006,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301001,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301002,
    vendorName: "Sam",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301003,
    vendorName: "John",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301004,
    vendorName: "Mary",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301005,
    vendorName: "Peter",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301006,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301001,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301002,
    vendorName: "Sam",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301003,
    vendorName: "John",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301004,
    vendorName: "Mary",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301005,
    vendorName: "Peter",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301006,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301001,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301002,
    vendorName: "Sam",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301003,
    vendorName: "John",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301004,
    vendorName: "Mary",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301005,
    vendorName: "Peter",
    phone: "+61 43232134",
    doj: ""
  },
  {
    vendorCode: 301006,
    vendorName: "Alex",
    phone: "+61 43232134",
    doj: ""
  }
];
