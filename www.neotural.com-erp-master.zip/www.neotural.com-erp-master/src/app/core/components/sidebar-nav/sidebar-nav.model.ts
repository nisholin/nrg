export interface MenuItem {
  id: string;
  label: string;
  icon: string;
  path: string;
  childern: any;
  submenu: boolean;
}
