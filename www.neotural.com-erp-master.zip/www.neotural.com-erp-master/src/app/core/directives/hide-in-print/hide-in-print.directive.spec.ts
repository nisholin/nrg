import { HideInPrintDirective } from './hide-in-print.directive';

describe('HideInPrintDirective', () => {
  it('should create an instance', () => {
    const directive = new HideInPrintDirective();
    expect(directive).toBeTruthy();
  });
});
