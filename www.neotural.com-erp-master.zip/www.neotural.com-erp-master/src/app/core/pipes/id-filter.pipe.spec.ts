import { IdFilterPipe } from './id-filter.pipe';

describe('IdFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new IdFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
