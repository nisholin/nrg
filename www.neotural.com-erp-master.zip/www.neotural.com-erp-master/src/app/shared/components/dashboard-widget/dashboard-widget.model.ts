export interface WidgetData {
  bgClass: string;
  title: string;
  icon: string;
  value: string | number;
  description: string;
}
