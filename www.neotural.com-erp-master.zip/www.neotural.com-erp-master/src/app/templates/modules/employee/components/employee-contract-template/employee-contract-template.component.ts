import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-contract-template',
  templateUrl: './employee-contract-template.component.html',
  styleUrls: ['./employee-contract-template.component.scss']
})
export class EmployeeContractTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
