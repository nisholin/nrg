export interface Employee {
  employeecode: string;
  name: string;
  rank: string;
  phonenumber: string;
}
