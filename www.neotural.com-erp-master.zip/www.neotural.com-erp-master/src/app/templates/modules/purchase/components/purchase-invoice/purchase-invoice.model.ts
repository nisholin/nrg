export interface Vendor {
  vendorCode: number;
  vendorName: string;
  phone: string;
  doj: string;
}
