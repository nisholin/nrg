export interface Customer {
  customercode: number;
  name: string;
  phonenumber: string;
  doj: string;
}
