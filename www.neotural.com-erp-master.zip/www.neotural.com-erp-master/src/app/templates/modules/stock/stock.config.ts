export const API_ENDPOINTS = { 
  LOAD_STOCK: `/stock/loadStock?status={param}`,
  updateStock: `/stock/updateStock`,
};
