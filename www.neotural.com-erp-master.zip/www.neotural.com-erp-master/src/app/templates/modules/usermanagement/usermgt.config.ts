export const API_ENDPOINTS = { 
    LOAD_DEPARTMENT: `/employee/load`,
};
