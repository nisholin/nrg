export const API_ENDPOINTS = {
  save: `/customer/save`,
  load: `/customer/load`,
  loadvendornamecode: `/customer/loadvendornamecode`,
  get: `/customer/get`,
  update: `/customer/update`,
  remove: `/customer/remove`
};
