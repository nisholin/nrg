export class SubMenuItem {
  name : string;

  pageName: string;

  constructor(name : string, pageName : string){
    this.name = name;
    this.pageName = pageName;
  }
 }
