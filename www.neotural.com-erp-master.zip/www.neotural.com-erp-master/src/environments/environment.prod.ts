export const environment = {
  production: true,
  apiUrl: "https://login.neotural.com/erp/"
};
